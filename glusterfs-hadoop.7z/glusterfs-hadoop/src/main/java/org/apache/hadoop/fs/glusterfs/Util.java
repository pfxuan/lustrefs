/**
 *
 * Copyright (c) 2013 Red Hat, Inc. <http://www.redhat.com>
 * This file is part of GlusterFS.
 *
 * Licensed under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * permissions and limitations under the License.
 *
 * Implements the Hadoop FileSystem Interface to allow applications to store
 * files on GlusterFS and run Map/Reduce jobs on the data.
 * 
 * 
 */

package org.apache.hadoop.fs.glusterfs;

import java.io.File;
import java.io.IOException;

import org.apache.hadoop.fs.FileUtil;
import org.apache.hadoop.util.Shell;

public class Util{

    public static String execCommand(File f,String...cmd) throws IOException{
        String[] args=new String[cmd.length+1];
        System.arraycopy(cmd, 0, args, 0, cmd.length);
        args[cmd.length]=FileUtil.makeShellPath(f, true);
        String output=Shell.execCommand(args);
        return output;
    }

    /* copied from unstalbe hadoop API org.apache.hadoop.Shell */
    public static String[] getGET_PERMISSION_COMMAND(){
        // force /bin/ls, except on windows.
        return new String[]{(WINDOWS ? "ls" : "/bin/ls"),"-ld"};
    }
    
    /* copied from unstalbe hadoop API org.apache.hadoop.Shell */
    
    public static final boolean WINDOWS /* borrowed from Path.WINDOWS */
    =System.getProperty("os.name").startsWith("Windows");
    // / loads permissions, owner, and group from `ls -ld`
}
